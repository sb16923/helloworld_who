﻿
Partial Class _Default
    Inherits Page
    Private DB As New HELLOWORLD_INSTALL_TESTEntities

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim Query = (From y In DB.tbl_colours Select y.colour, y.unique_id).ToList


        If Not Page.IsPostBack Then
            colours_DDL.DataSource = Query
            colours_DDL.DataTextField = "colour"
            colours_DDL.DataValueField = "unique_id"
            colours_DDL.DataBind()
        End If


    End Sub
End Class





